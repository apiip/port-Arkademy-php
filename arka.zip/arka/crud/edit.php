<?php
    require("db.php");

    $data = mysqli_query($koneksi, "SELECT * FROM categories");
    // kalo buat looping pilihan pake fetch all enak
    $categories = mysqli_fetch_all($data, MYSQLI_ASSOC);

    // var_dump($categories)
    $id = $_GET['id'];
    $edit = mysqli_query($koneksi, "SELECT * FROM articles where id = $id");
    $edit = mysqli_fetch_assoc($edit);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Article</title>
</head>
<body>
    <h2>Edit Article</h2>

    <form method="POST" action="action_edit.php">
        <p>
        <label for="">Title</label><br>
        <input type="text" name="title" value="<?=$edit['title'] ?>">
        </p>
    
        <p>
        <label for="">Category</label><br>
        <select name="category_id" id="">
            <?php foreach($categories as $category) { ?>
              <option value="<?php echo $category['id']; ?>" 
              
              <?= $category['id'] == $edit['category_id'] ? 'selected' : '' ?>
              >
              
              <?php echo $category['name']; ?> 
              </option>  

            <?php } ?>
        </select>
        </p>

        <p>
        <label for="">Content</label><br>
        <textarea name="content" id="" cols="30" rows="10"> <?=$edit['content'] ?> </textarea>
        </p>

        <input type="hidden" name="article_id" value="<?= $id ?>">

        <p><input type="submit" value="Edit Data"></p>
        <input type="button" value="Batal" href="index.php">
    </form>
</body>
</html>