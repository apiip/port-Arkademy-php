<?php 
    require("db.php");

    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE from articles where id=$id");

    header("location: index.php");

?>