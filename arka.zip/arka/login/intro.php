<?php 
    $counter = 0;
    if (isset($_COOKIE['counter'])) {
        
    }
    setcookie("counter", $counter, time() + 3600);

?>
